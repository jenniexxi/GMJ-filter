$(document).ready(function(){

        $('.gift-tab-list .tab-list-item').on('click',function(){      
        let thisIndex = $(this).index();

        $('.gift-tab-list button').removeClass('on')
        $(this).find('button').addClass('on')
        
        $('.gift-tab-content').hide()
        $('.gift-tab-content').eq(thisIndex).show()  //핵심은 리스트순번과 컨텐츠 클래스의 순서를 같게 맞춰주고 .show 를 해줌.
        //eq 는 컨텐츠의 순번 $(this).index()
    })
    $('.interest-tab-list .tab-list-item').on('click',function(){    
        let thisIndex = $(this).index();

        $('.interest-tab-list button').removeClass('on')
        $(this).find('button').addClass('on')
        
        $('.interest-tab-content').hide()
        $('.interest-tab-content').eq(thisIndex).show()  
    })
    $('.pick-tab-list .tab-list-item').on('click',function(){      
        let thisIndex = $(this).index();

        $('.pick-tab-list button').removeClass('on')
        $(this).find('button').addClass('on')
        
        $('.pick-tab-content').hide()
        $('.pick-tab-content').eq(thisIndex).show()  
    })
    
})
//스와이프
document.addEventListener("DOMContentLoaded", function() {

    var mySwiper = new Swiper('.swiper-container', {
        slidesPerView: 4,
        slidesPerGroup: 4,
        observer: true,
        observeParents: true,
        spaceBetween: 24,
        breakpoints: {
            // 1280: {
            //     slidesPerView: 3,
            //     slidesPerGroup: 3,
            // },
            720: {
                slidesPerView: 1,
                slidesPerGroup: 1,
                pagination : { // 페이징 설정
                    el : '.swiper-pagination',
                    clickable : true, // 페이징을 클릭하면 해당 영역으로 이동, 필요시 지정해 줘야 기능 작동
                },
            }
        }
    });
    
});